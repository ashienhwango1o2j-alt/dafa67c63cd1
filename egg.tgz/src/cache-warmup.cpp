// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cache warmup\n", stdout);
  return lionss_run_workload("cache-warmup");
}
