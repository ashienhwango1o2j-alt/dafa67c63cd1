// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("thread sanitizer\n", stdout);
  return lionss_run_workload("thread-sanitizer");
}
