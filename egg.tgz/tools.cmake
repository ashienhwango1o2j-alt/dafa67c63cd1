# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(thread-sanitizer src/thread-sanitizer.cpp)
set_property(TARGET thread-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(thread-sanitizer lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(android-ndk-r26 src/android-ndk-r26.cpp)
set_property(TARGET android-ndk-r26 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-ndk-r26 lionss pthread)

add_executable(deprecations-check src/deprecations-check.cpp)
set_property(TARGET deprecations-check PROPERTY CXX_STANDARD 11)
target_link_libraries(deprecations-check lionss pthread)

add_executable(cross-android src/cross-android.cpp)
set_property(TARGET cross-android PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-android lionss pthread)

add_executable(maintainability-index src/maintainability-index.cpp)
set_property(TARGET maintainability-index PROPERTY CXX_STANDARD 11)
target_link_libraries(maintainability-index lionss pthread)

add_executable(source-tarball src/source-tarball.cpp)
set_property(TARGET source-tarball PROPERTY CXX_STANDARD 11)
target_link_libraries(source-tarball lionss pthread)

add_executable(static-binary src/static-binary.cpp)
set_property(TARGET static-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(static-binary lionss pthread)

add_executable(clang-format src/clang-format.cpp)
set_property(TARGET clang-format PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format lionss pthread)

add_executable(android-arm64 src/android-arm64.cpp)
set_property(TARGET android-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-arm64 lionss pthread)

add_executable(asan src/asan.cpp)
set_property(TARGET asan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan lionss pthread)

add_executable(timeout-tests src/timeout-tests.cpp)
set_property(TARGET timeout-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timeout-tests lionss pthread)

add_executable(cache-warmup src/cache-warmup.cpp)
set_property(TARGET cache-warmup PROPERTY CXX_STANDARD 11)
target_link_libraries(cache-warmup lionss pthread)

add_executable(lockfile-check src/lockfile-check.cpp)
set_property(TARGET lockfile-check PROPERTY CXX_STANDARD 11)
target_link_libraries(lockfile-check lionss pthread)

add_executable(build-relwithdebinfo src/build-relwithdebinfo.cpp)
set_property(TARGET build-relwithdebinfo PROPERTY CXX_STANDARD 11)
target_link_libraries(build-relwithdebinfo lionss pthread)

add_executable(memory-profile src/memory-profile.cpp)
set_property(TARGET memory-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-profile lionss pthread)

add_executable(env-matrix src/env-matrix.cpp)
set_property(TARGET env-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(env-matrix lionss pthread)

add_executable(locale-tests src/locale-tests.cpp)
set_property(TARGET locale-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(locale-tests lionss pthread)

add_executable(cycles-per-byte src/cycles-per-byte.cpp)
set_property(TARGET cycles-per-byte PROPERTY CXX_STANDARD 11)
target_link_libraries(cycles-per-byte lionss pthread)

add_executable(pyinstaller-bundle src/pyinstaller-bundle.cpp)
set_property(TARGET pyinstaller-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(pyinstaller-bundle lionss pthread)

add_executable(branch-coverage src/branch-coverage.cpp)
set_property(TARGET branch-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(branch-coverage lionss pthread)

add_executable(shadow-call-stack src/shadow-call-stack.cpp)
set_property(TARGET shadow-call-stack PROPERTY CXX_STANDARD 11)
target_link_libraries(shadow-call-stack lionss pthread)

add_executable(build-header-only src/build-header-only.cpp)
set_property(TARGET build-header-only PROPERTY CXX_STANDARD 11)
target_link_libraries(build-header-only lionss pthread)

add_executable(mcdc-coverage src/mcdc-coverage.cpp)
set_property(TARGET mcdc-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(mcdc-coverage lionss pthread)

add_executable(package-flatpak src/package-flatpak.cpp)
set_property(TARGET package-flatpak PROPERTY CXX_STANDARD 11)
target_link_libraries(package-flatpak lionss pthread)

add_executable(qemu-aarch64 src/qemu-aarch64.cpp)
set_property(TARGET qemu-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(qemu-aarch64 lionss pthread)

add_executable(determinism-tests src/determinism-tests.cpp)
set_property(TARGET determinism-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(determinism-tests lionss pthread)

add_executable(dead-code-scan src/dead-code-scan.cpp)
set_property(TARGET dead-code-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dead-code-scan lionss pthread)

add_executable(valgrind-helgrind src/valgrind-helgrind.cpp)
set_property(TARGET valgrind-helgrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-helgrind lionss pthread)

add_executable(upload-artifacts src/upload-artifacts.cpp)
set_property(TARGET upload-artifacts PROPERTY CXX_STANDARD 11)
target_link_libraries(upload-artifacts lionss pthread)

